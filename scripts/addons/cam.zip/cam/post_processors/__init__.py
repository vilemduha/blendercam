################################################################################
# __init__.py
#
# This is here to make python see NC folder
#
# Hirutso Enni, 2009-01-13
